#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define MAX_USERS 10
#define CREDENTIAL_LENGTH 30

typedef struct {
    char username[CREDENTIAL_LENGTH];
    char password[CREDENTIAL_LENGTH];
} user;

user users[MAX_USERS];
int user_count = 0;

void register_user();
int login_user();
void fix_fgets_input(char*);
void input_credentials(char* username, char* password);

int main() {
    int option;
    while (1) {
        printf("\nWelcome to User Management");
        printf("\n1. Register");
        printf("\n2. Login");
        printf("\n3. Exit");
        printf("\nSelect an option: ");
        scanf("%d", &option);
        getchar(); 

        switch (option) {
            case 1:
                register_user();
                break;
            case 2: {
                int user_index = login_user();
                if (user_index >= 0) {
                    printf("\nLogin successful! Welcome, %s!\n", users[user_index].username);
                } else {
                    printf("\nLogin failed! Incorrect username or password.\n");
                }
                break;
            }
            case 3:
                printf("\nExiting program.\n");
                return 0;
            default:
                printf("\nInvalid option. Please try again.\n");
                break;
        }
    }
}

void register_user() {
    if (user_count == MAX_USERS) {
        printf("\nMaximum %d users supported! No more registrations allowed!\n", MAX_USERS);
        return;
    }

    int new_index = user_count;
    printf("\nRegister a new user\n");
    input_credentials(users[new_index].username, users[new_index].password);
    user_count++;
    printf("\nRegistration successful!\n");
    printf("Username: %s\nPassword: %s\n", users[new_index].username, users[new_index].password);
}

int login_user() {
    char username[CREDENTIAL_LENGTH];
    char password[CREDENTIAL_LENGTH];

    input_credentials(username, password);

    for (int i = 0; i < user_count; i++) {
        if (strcmp(username, users[i].username) == 0 &&
            strcmp(password, users[i].password) == 0) {
            return i;
        }
    }
    return -1;
}

void input_credentials(char* username, char* password) {
    printf("\nEnter the username: ");
    fgets(username, CREDENTIAL_LENGTH, stdin);
    fix_fgets_input(username);

    printf("Enter password (masking enabled): ");
    fflush(stdout);

    struct termios old_props, new_props;
    tcgetattr(STDIN_FILENO, &old_props);
    new_props = old_props;
    new_props.c_lflag &= ~(ECHO | ICANON);
    tcsetattr(STDIN_FILENO, TCSANOW, &new_props);

    char ch;
    int i = 0;

    while ((ch = getchar()) != '\n' && ch != EOF && i < CREDENTIAL_LENGTH - 1) {
        if (ch == 127 || ch == '\b') {
            if (i > 0) {
                i--;
                printf("\b \b"); 
            }
        } else {
            password[i++] = ch;
            printf("*");
        }
    }

    password[i] = '\0';
    tcsetattr(STDIN_FILENO, TCSANOW, &old_props);
    printf("\n");
}

void fix_fgets_input(char* string) {
    int index = strcspn(string, "\n");
    string[index] = '\0';
}

