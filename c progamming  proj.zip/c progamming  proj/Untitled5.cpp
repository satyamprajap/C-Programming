#include <stdio.h>
#include <string.h>

int main() {
    char str[100];
    int i, len;

    printf("Enter a word: ");
    scanf("%s", str);  // Reads a single word (no spaces)

    len = strlen(str);

    for (i = 0; i < len / 2; i++) {
        if (str[i] != str[len - i - 1]) {
            printf("Not a palindrome.\n");
            return 0;
        }
    }

    printf("It's a palindrome!\n");
����return�0;
}
