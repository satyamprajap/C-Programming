#include<stdio.h>
int main(){
 int num,rev=0,temp,digit;
  printf("enter a number");
  scanf("%d",&num);
  temp = num;
  while(temp !=0){
  	digit =temp%10;
  	rev = rev*10+digit;
  	temp/=10;
  }
  if(num==rev)
   		printf("%d is a palindrone:\n",num);
   	else
   	   printf("%d is not palindrone\n",num);
   	   return 0;
   }
