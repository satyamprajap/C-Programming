#include<stdio.h>
 int main(){
 	int n,size;
 	printf("enter the size fo indentity matrix:");
 	scanf("%d",&n);
 	printf("enter the size number");
 	scanf("%d",&size);
 	
 	 int matrix[n][n];
 	  for(int i=0;i<n;i++){
 	  	for(int j=0;j<n;j++){
 	  		if(i==j){
 	  		matrix[i][j]=size3;
		   }else{
		   	matrix[i][j]=0;
		   }
	   }
 }
 printf("identiy matrix of size %d%d:\n",n,n);
     for(int i=0;i<n;i++){
     	for(int j=0;j<n;j++){
     		printf("%d\t",matrix[i][j]);
		 }
		 printf("\n");
	 }
	 return 0;
}
