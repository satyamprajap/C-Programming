#include<stdio.h>
#include<string.h>
 int main(){
 	char str[100];
 	printf("enter a string");
 	gets(str);
 	strrev(str);
 	printf("reversed string:%s\n",str);
 	return 0;
 	
 	
 }
