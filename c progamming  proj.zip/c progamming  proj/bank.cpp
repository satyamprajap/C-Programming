#include<stdio.h>
#include<string.h>
 

 	
 	
 	void creat_accout();
 	void depoist_money();
 	void withdraw_money();
 	void check_balance();
 	
 	typedef struct{
 		char name[50];
 		int acc_no;
 		float balance;
	 }Account;
 	
  int main(){
 	while(1){
 		int choice;
 		printf("\n\n***Bank Management system*** ");
 		printf("\n1. Create account");
 		printf("\n2 Deposit maney");
 		printf("\n3 With drow money");
 		printf("\n4 Check Balance");
 		printf("\n5 Exit");
 		printf("\nEnter your choice:");
 		scanf("%d",&choice);
 		
 		switch (choice){
 			case 1:
 				creat_accout();
 				break;
 			case 2:
 				depoist_money();
 				break;
 			case 3:
 				withdraw_money();
 				break;
 			case 4:
 				check_balance();
 				break;
 		    case 5:
 		    	printf("\nclosing the bank,Thanks for your visit.\n");
 		    	return 0;
 		    	 break;
 			default:
 				printf("\nInvalid choice!");
 				break;
 				
 			 
		 }
 		
	 }
 	
 }
  	
 	void create_account(){
 		Account acc;
 		 FILE*file=fopen("account.dat","ab+");
 		 if(file==NULL){
 		 	printf("\nunable to open file!!");
 		 	return;
 		 }
 		printf("\n Enter your name:");
 		fgets(acc.name,sizeof(acc.name),stdin);
 		acc.name[strcspn(acc.name,"\n")]='\0';
 	
 		printf("Enter your account number:");
 		scanf("%d",&acc.acc_no);
 		acc.balance = 0;
 		
 		fwrite(&acc,sizeof(acc),1,file);
 		fclose(file);
 		printf("\n Account created successfully!");
	 }
 	void depoist_money(){
 		printf("\n  depositing  money");
	 }
 	void withdraw_money(){
 		printf("\n withdraw  money");
	 }
 	void check_balance(){
 		printf("\n check balance");
	 }
 	
